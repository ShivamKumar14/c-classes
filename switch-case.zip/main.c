/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int marks;
    printf("your marks is (0-100):");
    scanf("%d", &marks);
    
    switch(marks/10){
        case 10:
        case 9:
           printf("You have A grade\n");
           break;
        
        case 8:
           printf("You have B grade\n");
           break;
        
        case 7:
        printf("You have C grade\n");
        break;
        
        case 6:
        printf("You have D grade\n");
        break;
        
        default :
          printf("You are Fail\n");
          break;
    }

    return 0;
}
